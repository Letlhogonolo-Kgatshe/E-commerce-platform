﻿using System.ComponentModel.DataAnnotations;

namespace ST10445158_CLDV6211_Part1.Models
{
    public class Product
    {
     [Key]  // Marks this as the Primary Key
            public int Id { get; set; }
            public string Name { get; set; }
            public decimal Price { get; set; }
            public string Description { get; set; }
    }
}
