﻿using ST10445158_CLDV6211_Part1.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ST10445158_CLDV6211_Part1.Models
{
    public class Order
    {
        [Key]  // Primary Key
        public int OrderId { get; set; }

        [Required]
        public string CustomerName { get; set; }

        [Required]
        [EmailAddress]
        public string CustomerEmail { get; set; }

        [Required]
        public DateTime OrderDate { get; set; } = DateTime.Now;

        [Required]
        public int ProductId { get; set; }  // Foreign Key linking to Product table

        [ForeignKey("ProductId")]
        public Product Product { get; set; }  // Navigation property

        public int Quantity { get; set; }

        [Required]
        public decimal TotalPrice { get; set; }
    }
}
