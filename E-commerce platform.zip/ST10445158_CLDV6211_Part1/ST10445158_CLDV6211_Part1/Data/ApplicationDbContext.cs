﻿using Microsoft.EntityFrameworkCore;
using ST10445158_CLDV6211_Part1.Models;

namespace ST10445158_CLDV6211_Part1.Data
{
    public class ApplicationDbContext : DbContext
    {
        // Constructor: Passes options to the base class
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        // DbSet represents a table in the database
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
    }
}
