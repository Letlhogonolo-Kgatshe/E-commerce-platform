﻿using Microsoft.AspNetCore.Mvc;
using ST10445158_CLDV6211_Part1.Data;

namespace ST10445158_CLDV6211_Part1.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProductsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var products = _context.Products.ToList();
            return View(products);
        }
    }
}
