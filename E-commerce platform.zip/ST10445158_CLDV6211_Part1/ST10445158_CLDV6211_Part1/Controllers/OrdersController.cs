﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ST10445158_CLDV6211_Part1.Data;
using System.Linq;


namespace ST10445158_CLDV6211_Part1.Controllers
{
    public class OrdersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OrdersController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var orders = _context.Orders
                                 .Include(o => o.Product)  // Include Product details
                                 .ToList();
            return View(orders);
        }
    }
}


